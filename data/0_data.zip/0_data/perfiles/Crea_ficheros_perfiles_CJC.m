%%% CREAR FICHEROS PERFILES
% ************************************************************************
% Autor: Camilo Jaramillo Cardona
% camilo.jaramillo@unican.es
% 09/05/2018
% ************************************************************************
clear all close all clc

%% Cargar datos consolidados
T=readtable('Perfiles_Narrabeen.xlsx')
T2=table2array(T);

Num_perfil=T2(:,1);
X_ini=T2(:,2);
Y_ini=T2(:,3);
X_fin=T2(:,4);
Y_fin=T2(:,5);

%% Guardar cada perfil en un fichero

perfiles_X=[];
perfiles_Y=[];

for i=1:length(Num_perfil);
    %% Ficheros por separado perfil#.dat -- Para 2.ROTURA
%     Profile=[X_ini(i),Y_ini(i);X_fin(i),Y_fin(i)];
    Profile=[X_ini(i),X_fin(i);Y_ini(i),Y_fin(i)];
%     save (['perfil',num2str(Num_perfil(i)),'.dat'],'Profile','-ascii');
    
    %% Fichero consolidado perfiles.dat -- Para 4.DISTANCIA
    PX=[X_ini(i);X_fin(i)];
    PY=[Y_ini(i);Y_fin(i)];
    perfiles_X=[perfiles_X;PX]; % Guarda todas las coordenas X de todos los perfiles
    perfiles_Y=[perfiles_Y;PY]; % Guarda todas las coordenas Y de todos los perfiles
end

perfiles=[perfiles_X perfiles_Y]; % Matriz consolidada para script de Distancia
% save('C:\Users\jaramilloc\Documents\Camilo_Jaramillo\Doctorado\Datos_Playas\Narrabeen_Beach\CJC\Modelo_long_shore_Gainza\4distancia\perfiles.dat','perfiles','-ascii');