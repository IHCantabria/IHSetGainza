%%% CREAR FICHERO DOW.dat
% Se guarda el putno DOW reconstruido obtenido a partir del cache del SMC
% ************************************************************************
% Autor: Camilo Jaramillo Cardona
% camilo.jaramillo@unican.es
% 09/05/2018
% ************************************************************************
clear all close all clc

%% Cargar DOW reconstruido
dcache=loadDOWCache('wd_-34_151.5.dow');

fecha=datevec(dcache.time);
dow=[fecha dcache.hs dcache.tp dcache.dir];
save ('dow.dat','dow','-ascii');